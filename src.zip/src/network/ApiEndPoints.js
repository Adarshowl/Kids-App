export const BASE_URL = '';


export const API_END_POINTS = {
  API_LOGIN: `${BASE_URL}login`,

};

export const API_TYPE = {
  POST: 'post',
  GET: 'get',
};
