export const FONTS = {
  light: 'Outfit-Light',
  semi_bold: 'Outfit-SemiBold',
  thin: 'Outfit-Thin',
  regular: 'Outfit-Regular',
  bold: 'Outfit-Bold',
  medium: 'Outfit-Medium',
  extra_bolf: 'Outfit-ExtraBold',
  extra_light: "Outfit-ExtraLight",
  black: 'Outfit-Black'
};
