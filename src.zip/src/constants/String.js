export const STRING = {
  app_name: 'Body Recom',
  email : "Email" ,
  password: 'Password',
  name :'Name'
};
