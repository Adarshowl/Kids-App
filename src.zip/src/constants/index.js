import { COLORS } from './Colors';
import { SIZES } from './themes';
import { STRING } from './String';
import { images } from './images';
import { icons } from './icons';
import { FONTS } from './Fonts';

export { COLORS, FONTS,SIZES, STRING, images, icons };
